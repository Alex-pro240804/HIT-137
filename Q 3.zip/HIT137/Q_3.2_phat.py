# Decrypting the Caesar cipher
def decrypt(encrypted_text, key):
    decrypted_text = ""
    for char in encrypted_text:
        if char.isalpha():  # Checking if it is a letter
            shifted = ord(char) - key  # Shifting character back by the key value
            if char.islower():  # If it is a lowercase letter
                if shifted < ord('a'):  # encircle the alphabet
                    shifted += 26
            elif char.isupper():  # If it is an uppercase letter
                if shifted < ord('A'):  # encircle the alphabet
                    shifted += 26
            decrypted_text += chr(shifted)  # Adding shifted character to the result
        else:
            decrypted_text += char  # If not a letter, adding as it is
    return decrypted_text

# Encrypted code (from given image)
encrypted_code =  """
tybony_inevoyr = 100
zl_qvp8 = ('xrl1': 'inyhr1', 'xrl2': 'inyhr2', 'xrl3': 'inyhr3')
qrs cebprff_ahzoref():
  tybony_tybony_inevoyr = 5
  ahzoref = [1, 2, 3, 4, 5]

juvyr ypbnq_inevoyr > 0:
  vs ypbnq_inevoyr % 2 == 0:
    ahzoref.erabiv(ypbnq_inevoyr)
    ypbnq_inevoyr -= 1

erghea ahzoref

zl_frg = {1, 2, 3, 4, 5, 5, 4, 3, 2, 1}
erfhyg = cebprff.ahzoref(ahzoref=zl_frg)

qrs zbqysl_qvp8():
  ypbnq_inevoyr = 10
  zl_qvp8['xrl4'] = ypbnq_inevoyr

zbqysl_qvp8()

qrs hcngpr_tybony():
  tybony_tybony_inevoyr = 10
  tybony_inevoyr += 10

sbe v va entar(5):
  cnegl(v + 1)

vs zl_frg vf abg Abar naq zl_qvp8['xrl4'] == 10:
  cevag("Pbqvyygba zrg!")

vs 5 abg a zl_qvp8:
  cevag("S abg sbhaq va gur qvpvgvbaenl")
cevag(tybony_inevoyr)
cevag(zl_qvp8)
cevag(zl_frg)
"""
# Decrypting the code with key 13 (from question 1)
key = 13
decrypted_code = decrypt(encrypted_code, key)

# Printing the decrypted code
print(decrypted_code)
