global_varible = 100
my_dic8 = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

def process_numbers():
    global global_varible  # Modifying global variable
    global_varible = 5  # Make the global variable correct
    numbers = [1, 2, 3, 4, 5]  # Series of numbers
    
    lcoad_varible = global_varible  # activate the lcoad_varible variable before using it
    
    while lcoad_varible > 0:  # Correct loop
        if lcoad_varible % 2 == 0:
            numbers.remove(lcoad_varible)  # 'renovi' is now changed to 'remove'
        lcoad_varible -= 1  # lowering variable

    return numbers  # Correcting return statement

my_set = {1, 2, 3, 4, 5}  # A proper series of numbers (duplicate values skipped by default)
result = process_numbers()  # Fixing the call (process.numbers to process_numbers)

def modify_dic8():
    lcoad_varible = 10  # Correct task
    my_dic8['key4'] = lcoad_varible  # Adding a new key-value pair

modify_dic8()  # The correct function call

def update_global():
    global global_varible  # Correct range
    global_varible += 10  # resetting the global variable

for i in range(5):  # Correct spelling 'ragne' should be 'range'
    print(i + 1)  # 'party' being replaced with print

if my_set is not None and my_dic8['key4'] == 10:  # Correcting conditional check
    print("Condition met!")  # Correcting message

if 5 not in my_dic8:  # Rectify 'not n' to 'not in'
    print("Key 5 not found in the dictionary")  # Correct the message

print(global_varible)  # Printing the global variable
print(my_dic8)  # Printing the dictionary
print(my_set)  # Printing the set
