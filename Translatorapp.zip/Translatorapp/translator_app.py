import tkinter as tk
from tkinter import messagebox
from transformers import MarianMTModel, MarianTokenizer

# Base class
class TranslatorApp:
    def __init__(self):
        # Initialize the Tkinter root window
        self.root = tk.Tk()
        self.root.title("Language Translation App")
        self.root.geometry("400x300")

        # Load the translation model
        self._model_name = 'Helsinki-NLP/opus-mt-en-es'
        self._tokenizer = MarianTokenizer.from_pretrained(self._model_name)
        self._model = MarianMTModel.from_pretrained(self._model_name)

        # Setup the widgets
        self.create_widgets()

    def create_widgets(self):
        # Input text field
        self.input_label = tk.Label(self.root, text="Enter Text (English):")
        self.input_label.pack(pady=10)
        self.input_text = tk.Entry(self.root, width=50)
        self.input_text.pack(pady=5)

        # Output text field
        self.output_label = tk.Label(self.root, text="Translated Text (Spanish):")
        self.output_label.pack(pady=10)
        self.output_text = tk.Entry(self.root, width=50)
        self.output_text.pack(pady=5)

        # Translate button
        self.translate_button = tk.Button(self.root, text="Translate", command=self.translate)
        self.translate_button.pack(pady=10)

        # Quit button
        self.quit_button = tk.Button(self.root, text="Quit", command=self.root.quit)
        self.quit_button.pack(pady=10)

    def translate(self):
        input_text = self.input_text.get()
        if not input_text:
            messagebox.showwarning("Input Error", "Please enter some text to translate!")
            return

        translated = self._translate_text(input_text)
        self.output_text.delete(0, tk.END)
        self.output_text.insert(tk.END, translated)

    def _translate_text(self, text):
        inputs = self._tokenizer([text], return_tensors="pt", max_length=512, truncation=True)
        outputs = self._model.generate(**inputs)
        translated_text = self._tokenizer.decode(outputs[0], skip_special_tokens=True)
        return translated_text

# Decorator to log function calls
def log_function_call(func):
    def wrapper(*args, **kwargs):
        print(f"Function '{func.__name__}' was called.")
        return func(*args, **kwargs)
    return wrapper

# Derived class for logging
class LoggingTranslatorApp(TranslatorApp):
    def translate(self):
        print("Translating text with LoggingTranslatorApp.")
        super().translate()

# Mixin class for additional features
class AdditionalFeatureMixin:
    def set_translation_language(self, language_code):
        print(f"Setting translation language to: {language_code}")
        self._model_name = f'Helsinki-NLP/opus-mt-en-{language_code}'
        self._tokenizer = MarianTokenizer.from_pretrained(self._model_name)
        self._model = MarianMTModel.from_pretrained(self._model_name)

# Combined advanced class
class AdvancedTranslatorApp(LoggingTranslatorApp, AdditionalFeatureMixin):
    def __init__(self):
        super().__init__()

    @log_function_call
    def start(self):
        self.root.mainloop()

# Main execution
if __name__ == "__main__":
    app = AdvancedTranslatorApp()
    app.start()
